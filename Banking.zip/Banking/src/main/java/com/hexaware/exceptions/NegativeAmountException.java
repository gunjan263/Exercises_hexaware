package com.hexaware.exceptions;

public class NegativeAmountException extends Exception {

    private static final long serialVersionUID = 1L; // Add a serial version UID

    public NegativeAmountException() {
        super("Amount cannot be negative");
    }

    public NegativeAmountException(String message) {
        super(message + " Amount cannot be negative");
    }
}
