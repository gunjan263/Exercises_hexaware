package com.hexaware.exceptions;

public class AccountNumberInvalidException extends Exception {

    private static final long serialVersionUID = 1L; // Add a serial version UID

    public AccountNumberInvalidException() {
        super("Account number is invalid");
    }

    public AccountNumberInvalidException(String message) {
        super(message + " Account number is invalid");
    }
}
