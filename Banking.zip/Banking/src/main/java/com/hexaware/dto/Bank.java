// Bank.java
package com.hexaware.dto;

import java.util.ArrayList;
import java.util.List;

public class Bank {
    private String bankName;
    private List<BankAccount> accountList;
    private static long lastAccountNumber = 1109; // Starting account number

    public Bank(String bankName) {
        this.bankName = bankName;
        this.accountList = new ArrayList<>();
    }

    public String getBankName() {
        return bankName;
    }

    public List<BankAccount> getAccountList() {
        return new ArrayList<>(accountList);
    }

    public BankAccount searchAccount(long accountNumber) {
        for (BankAccount account : accountList) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }

    public void createAccount(String holderName, String accountType, double initialBalance) {
        try {
            long accountNumber = generateAccountNumber();
            BankAccount newAccObj = new BankAccount(accountNumber, holderName, accountType, initialBalance);
            accountList.add(newAccObj);
        } catch (Exception e) {
            System.out.println("Error in creating account: " + e.getMessage());
        }
    }

    private synchronized long generateAccountNumber() {
        return ++lastAccountNumber;
    }

    public boolean removeAccount(long accountNumber) {
        try {
            BankAccount reqAccount = searchAccount(accountNumber);
            if (reqAccount != null) {
                accountList.remove(reqAccount);
                return true;
            } else {
                System.out.println("Account does not exist");
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error in removing account: " + e.getMessage());
            return false;
        }
    }

    @Override
    public String toString() {
        return "Bank{" +
                "bankName='" + bankName + '\'' +
                ", accountList=" + accountList +
                '}';
    }
}
