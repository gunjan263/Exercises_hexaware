package com.hexaware.main;

import com.hexaware.dao.ServiceProviderImpl;
import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.exceptions.NegativeAmountException;
import com.hexaware.security.Login;

public class Mainmod {

    public static void main(String[] args) throws NegativeAmountException, NegativeAmountException {

        // Perform login
        boolean loggedIn = Login.authenticate();

        if (!loggedIn) {
            System.out.println("Exiting application.");
            return;
        }


        Bank myBank = new Bank("ICICI");
        System.out.println(myBank);

        ServiceProviderImpl myServiceObj = new ServiceProviderImpl(myBank);

        // Create BankAccounts using createAccount method
        BankAccount obj1 = new BankAccount(1110, "Sachin", "Current", 80000.50);
        BankAccount obj2 = new BankAccount(1111, "Nisha", "Savings", 20000.50);
        BankAccount obj3 = new BankAccount(1112, "Roshid", "Current", 35000.50);

        myServiceObj.createAccount(obj1);
        myServiceObj.createAccount(obj2);
        myServiceObj.createAccount(obj3);

        // Display account details
        System.out.println("Accounts in the bank: " + myBank.getAccountList());

        // Perform operations
        System.out.println("Balance of account 1111: " + myServiceObj.checkBalance(1111));
        System.out.println("Status of deposit: " + myServiceObj.deposit(1111, 5000.50));
        System.out.println("Balance of account 1111: " + myServiceObj.checkBalance(1111));

        System.out.println("Status of withdrawal: " + myServiceObj.withdraw(1112, 5000.50));
        System.out.println("Balance of account 1112: " + myServiceObj.checkBalance(1112));
    }
}
