// ServiceProviderImpl.java
package com.hexaware.dao;

import com.hexaware.dto.Bank;
import com.hexaware.dto.BankAccount;
import com.hexaware.exceptions.NegativeAmountException;
import com.hexaware.exceptions.AccountNumberInvalidException;

public class ServiceProviderImpl implements IServiceProvider {
    private Bank myBank;

    public ServiceProviderImpl(Bank myBank) {
        this.myBank = myBank;
    }

    @Override
    public BankAccount searchAccount(long accountNumber) {
        for (BankAccount account : myBank.getAccountList()) {
            if (account.getAccountNumber() == accountNumber) {
                return account;
            }
        }
        return null;
    }

    @Override
    public double checkBalance(long accountNumber) {
        BankAccount reqAccount = searchAccount(accountNumber);
        return (reqAccount != null) ? reqAccount.getBalance() : -1.0;
    }

    @Override
    public boolean deposit(long accountNumber, double amount) {
        try {
            BankAccount reqAccount = searchAccount(accountNumber);
            if (amount > 0) {
                if (reqAccount != null) {
                    reqAccount.setBalance(reqAccount.getBalance() + amount);
                    return true;
                } else {
                    throw new AccountNumberInvalidException("Account does not exist");
                }
            } else {
                System.out.println("Invalid amount");
            }
        } catch (AccountNumberInvalidException e) {
            System.out.println("Error in depositing: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean withdraw(long accountNumber, double amount) throws NegativeAmountException {
        try {
            BankAccount reqAccount = searchAccount(accountNumber);
            if (reqAccount != null) {
                if (amount > 0) {
                    if (reqAccount.getBalance() >= amount) {
                        reqAccount.setBalance(reqAccount.getBalance() - amount);
                        return true;
                    } else {
                        System.out.println("Insufficient funds");
                    }
                } else {
                    throw new NegativeAmountException("Invalid withdrawal amount");
                }
            } else {
                throw new AccountNumberInvalidException("Account does not exist");
            }
        } catch (AccountNumberInvalidException | NegativeAmountException e) {
            System.out.println("Error in withdrawing: " + e.getMessage());
        }
        return false;
    }

    @Override
    public void createAccount(BankAccount newAcc) {
        try {
            myBank.createAccount(newAcc.getHolderName(), newAcc.getAccountType(), newAcc.getBalance());
        } catch (Exception e) {
            System.out.println("Error in creating account: " + e.getMessage());
        }
    }

    @Override
    public boolean removeAccount(long accountNumber) {
        try {
            return myBank.removeAccount(accountNumber);
        } catch (Exception e) {
            System.out.println("Error in removing account: " + e.getMessage());
            return false;
        }
    }
}
