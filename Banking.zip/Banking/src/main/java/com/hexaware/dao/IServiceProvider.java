// IServiceProvider.java
package com.hexaware.dao;

import com.hexaware.dto.BankAccount;
import com.hexaware.exceptions.NegativeAmountException;

public interface IServiceProvider {
    BankAccount searchAccount(long accountNumber);
    double checkBalance(long accountNumber);
    boolean deposit(long accountNumber, double amount);
    boolean withdraw(long accountNumber, double amount) throws NegativeAmountException;
    void createAccount(BankAccount newAcc);
    boolean removeAccount(long accountNumber);
}
