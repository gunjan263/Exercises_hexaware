package com.hexaware.security;
import java.util.Scanner;

public class Login {
    private static final String VALID_USERNAME = "user123";
    private static final String VALID_PASSWORD = "pass123";

    public static boolean authenticate() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (isValidCredentials(username, password)) {
            System.out.println("Login successful!");
            return true;
        } else {
            System.out.println("Invalid credentials. Login failed.");
            return false;
        }
    }

    private static boolean isValidCredentials(String username, String password) {
        return VALID_USERNAME.equals(username) && VALID_PASSWORD.equals(password);
    }
}
