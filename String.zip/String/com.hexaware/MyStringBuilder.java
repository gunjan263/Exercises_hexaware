package com.hexaware;

public class MyStringBuilder {
    private java.lang.StringBuilder stringBuilder;

    public MyStringBuilder() {
        stringBuilder = new java.lang.StringBuilder();
    }

    public void append(String text) {
        stringBuilder.append(text);
    }

    public void insert(int index, String text) {
        if (index < 0 || index > stringBuilder.length()) {
            throw new IllegalArgumentException("Index out of bounds");
        }
        stringBuilder.insert(index, text);
    }

    public void delete(int start, int end) {
        if (start < 0 || end > stringBuilder.length() || start > end) {
            throw new IllegalArgumentException("Invalid start or end index");
        }
        stringBuilder.delete(start, end);
    }

    @Override
    public String toString() {
        return stringBuilder.toString();
    }

    public static void main(String[] args) {
        MyStringBuilder builder = new MyStringBuilder();
        builder.append("Hello, ");
        builder.append("world!");
        System.out.println(builder);  // Output: Hello, world!

        builder.insert(7, "awesome ");
        System.out.println(builder);  // Output: Hello, awesome world!

        builder.delete(7, 15);
        System.out.println(builder);  // Output: Hello, world!
    }
}
