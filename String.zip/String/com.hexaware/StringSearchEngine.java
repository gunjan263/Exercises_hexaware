package com.hexaware;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringSearchEngine {
    private String originalText;

    public StringSearchEngine(String originalText) {
        this.originalText = originalText;
    }

    public List<String> findAllOccurrences(String substring) {
        List<String> occurrences = new ArrayList<>();
        Pattern pattern = Pattern.compile(substring);
        Matcher matcher = pattern.matcher(originalText);

        while (matcher.find()) {
            occurrences.add(matcher.group());
        }

        return occurrences;
    }

    public String highlightOccurrences(String substring) {
        String highlightedText = originalText;
        Pattern pattern = Pattern.compile(substring);
        Matcher matcher = pattern.matcher(originalText);

        StringBuffer stringBuffer = new StringBuffer();

        while (matcher.find()) {
            matcher.appendReplacement(stringBuffer, "<b>" + matcher.group() + "</b>");
        }

        matcher.appendTail(stringBuffer);
        highlightedText = stringBuffer.toString();

        return highlightedText;
    }

    public static void main(String[] args) {
        String originalText = "This is a sample text. Sample text is used for demonstration.";
        StringSearchEngine searchEngine = new StringSearchEngine(originalText);

        String substringToFind = "sample";
        List<String> occurrences = searchEngine.findAllOccurrences(substringToFind);

        System.out.println("Occurrences of '" + substringToFind + "': " + occurrences);

        String highlightedText = searchEngine.highlightOccurrences(substringToFind);
        System.out.println("Highlighted Text: \n" + highlightedText);
    }
}
