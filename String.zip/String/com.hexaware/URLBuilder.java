package com.hexaware;

import java.util.Map;

public class URLBuilder {
    private String protocol;
    private String host;
    private String path;
    private Map<String, String> queryParameters;

    public URLBuilder() {
        
    }

    public URLBuilder setProtocol(String protocol) {
        this.protocol = protocol;
        return this;
    }

    public URLBuilder setHost(String host) {
        this.host = host;
        return this;
    }

    public URLBuilder setPath(String path) {
        this.path = path;
        return this;
    }

    public URLBuilder setQueryParameters(Map<String, String> queryParameters) {
        this.queryParameters = queryParameters;
        return this;
    }

    public String build() {
        StringBuilder urlBuilder = new StringBuilder();
        if (protocol != null) {
            urlBuilder.append(protocol).append("://");
        }
        if (host != null) {
            urlBuilder.append(host);
        }
        if (path != null) {
            urlBuilder.append("/").append(path);
        }
        if (queryParameters != null && !queryParameters.isEmpty()) {
            urlBuilder.append("?");
            for (Map.Entry<String, String> entry : queryParameters.entrySet()) {
                urlBuilder.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }
            urlBuilder.deleteCharAt(urlBuilder.length() - 1); // Remove the trailing "&"
        }
        return urlBuilder.toString();
    }

    public static void main(String[] args) {
        URLBuilder urlBuilder = new URLBuilder();
        String builtUrl = urlBuilder
                .setProtocol("https")
                .setHost("www.example.com")
                .setPath("path/to/resource")
                .setQueryParameters(Map.of("param1", "value1", "param2", "value2"))
                .build();

        System.out.println("Built URL: " + builtUrl);
    }
}
